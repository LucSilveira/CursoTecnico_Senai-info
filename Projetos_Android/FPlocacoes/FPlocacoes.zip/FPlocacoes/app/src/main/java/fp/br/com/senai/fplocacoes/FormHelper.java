package fp.br.com.senai.fplocacoes;

import android.widget.EditText;

import fp.br.com.senai.fplocacoes.MainActivityCars;
import fp.br.com.senai.fplocacoes.R;
import fp.br.com.senai.fplocacoes.models.Transporte;

public class FormHelper {

    public EditText modelo;
    public EditText placa;
    public EditText marca;
    public EditText ano;
    public EditText cor;
    public EditText tipoCarro;
    public EditText lugares;
    public Transporte transp;

    public FormHelper(MainActivityCars form){
        modelo = form.findViewById(R.id.setModelo);
        placa = form.findViewById(R.id.setPlaca);
        marca = form.findViewById(R.id.setMarca);
        ano = form.findViewById(R.id.setAno);
        cor = form.findViewById(R.id.setCor);
        tipoCarro = form.findViewById(R.id.setTipo);
        lugares = form.findViewById(R.id.setLugares);
        transp = new Transporte();
    }

    public Transporte pegaTransporte(){
        transp.setModelo(modelo.getText().toString());
        transp.setPlaca(placa.getText().toString());
        transp.setMarca(marca.getText().toString());
        transp.setAno(ano.getText().toString());
        transp.setCor(cor.getText().toString());
        transp.setTipoCarro(tipoCarro.getText().toString());
        transp.setLugares(lugares.getText().toString());
        return transp;
    }

    public void preencherForm (Transporte transp){
    modelo.setText(transp.getModelo());
    placa.setText(transp.getPlaca());
    marca.setText(transp.getMarca());
    ano.setText(transp.getAno());
    cor.setText(transp.getCor());
    tipoCarro.setText(transp.getTipoCarro());
    lugares.setText(transp.getLugares());
    this.transp = transp;
    }

}
